package SayHelloExtended;

class European extends BasePerson implements Person{
    private String name;

    European(String name) {
        super(name);
    }
}