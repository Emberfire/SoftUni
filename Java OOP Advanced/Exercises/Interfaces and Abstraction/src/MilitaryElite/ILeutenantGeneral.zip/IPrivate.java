package MilitaryElite;

interface IPrivate {
    double getSalary();
}