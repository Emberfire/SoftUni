package MilitaryElite;

import java.util.Set;

interface IEngineer {
    Set<Repair> getRepairs();
}