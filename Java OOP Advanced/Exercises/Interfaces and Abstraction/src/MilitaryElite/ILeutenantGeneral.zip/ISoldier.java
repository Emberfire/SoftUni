package MilitaryElite;

interface ISoldier {
    String getId();
    String getFirstName();
    String getLastName();
}