package MilitaryElite;

interface ISpy {
    String getCodeNumber();
}