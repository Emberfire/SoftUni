package MilitaryElite;

interface ISpecialisedSoldier {
    String getCorps();
}