package MilitaryElite;

import java.util.Set;

interface ICommando {
    Set<Mission> getMissions();
}