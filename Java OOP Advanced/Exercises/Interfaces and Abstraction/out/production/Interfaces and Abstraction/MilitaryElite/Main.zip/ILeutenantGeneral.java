package MilitaryElite;

import java.util.Set;

interface ILeutenantGeneral {
    Set<Soldier> getSoldiers();
}