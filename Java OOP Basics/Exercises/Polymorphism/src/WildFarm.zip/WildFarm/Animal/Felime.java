package WildFarm.Animal;

public abstract class Felime extends Mammal {
    Felime(String animalType, String animalName, double animalWeight, String animalLivingRegion) {
        super(animalType, animalName, animalWeight, animalLivingRegion);
    }
}