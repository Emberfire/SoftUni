class CleansingCenter extends Center {
    CleansingCenter(String name) {
        super(name);
    }
}