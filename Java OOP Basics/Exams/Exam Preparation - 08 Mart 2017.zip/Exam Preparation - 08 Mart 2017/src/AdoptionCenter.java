class AdoptionCenter extends Center {
    AdoptionCenter(String name) {
        super(name);
    }
}