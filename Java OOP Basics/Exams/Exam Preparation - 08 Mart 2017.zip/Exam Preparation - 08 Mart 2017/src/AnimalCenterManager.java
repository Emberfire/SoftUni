import java.util.ArrayList;
import java.util.HashMap;

public abstract class AnimalCenterManager {
    private HashMap<String, AdoptionCenter> adoptionCenters;
    private HashMap<String, CleansingCenter> cleansingCenters;

    private ArrayList<String> adoptedAnimals;
    private ArrayList<String> cleansedAnimals;


    AnimalCenterManager(String name) {
        this.setAdoptedAnimals(new ArrayList<>());
        this.setCleansedAnimals(new ArrayList<>());
        this.setAdoptionCenters(new HashMap<>());
        this.setCleansingCenters(new HashMap<>());
    }

    public void registerAdoptionCenter(AdoptionCenter adoptionCenter) {
        adoptionCenters.put(adoptionCenter.getName(), adoptionCenter);
    }

    public HashMap<String, AdoptionCenter> getAdoptionCenters() {
        return this.adoptionCenters;
    }

    public void setAdoptionCenters(HashMap<String, AdoptionCenter> adoptionCenters) {
        this.adoptionCenters = adoptionCenters;
    }

    public HashMap<String, CleansingCenter> getCleansingCenters() {
        return this.cleansingCenters;
    }

    public void setCleansingCenters(HashMap<String, CleansingCenter> cleansingCenters) {
        this.cleansingCenters = cleansingCenters;
    }

    public ArrayList<String> getAdoptedAnimals() {
        return this.adoptedAnimals;
    }

    public void setAdoptedAnimals(ArrayList<String> adoptedAnimals) {
        this.adoptedAnimals = adoptedAnimals;
    }

    public ArrayList<String> getCleansedAnimals() {
        return this.cleansedAnimals;
    }

    public void setCleansedAnimals(ArrayList<String> cleansedAnimals) {
        this.cleansedAnimals = cleansedAnimals;
    }
}