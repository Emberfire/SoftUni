package MultilevelInheritance;

class Animal {
    String eat() {
        return "eating...";
    }
}
