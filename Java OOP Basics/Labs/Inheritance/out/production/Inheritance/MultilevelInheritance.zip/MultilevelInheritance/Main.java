package MultilevelInheritance;

class Main {
    public static void main(String[] args) {
        Puppy puppy = new Puppy();

        System.out.printf("%s%n%s%n%s%n", puppy.eat(), puppy.bark(), puppy.weep());
    }
}