package MultilevelInheritance;

class Puppy extends Dog{
    String weep() {
        return "weeping...";
    }
}
