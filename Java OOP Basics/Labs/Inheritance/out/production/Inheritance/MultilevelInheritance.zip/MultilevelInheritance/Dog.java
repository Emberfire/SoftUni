package MultilevelInheritance;

class Dog extends Animal{
    String bark() {
        return "barking...";
    }
}
